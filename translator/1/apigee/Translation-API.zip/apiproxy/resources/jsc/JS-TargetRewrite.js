context.setVariable("target.copy.pathsuffix", false); 

//var targetURL = "us-central1-aiplatform.googleapis.com/v1/projects/" + PROJECT_ID + "/locations/us-central1/endpoints/" + ENDPOINT_ID + ":predict";

//context.setVariable("target.url",targetURL);